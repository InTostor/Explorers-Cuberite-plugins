require "turtle"

for i=1,12 do
  for j=1,12 do
    move(50)
    turn(30)
  end
  turn(30)
  wait(0.1)
end

wait()
